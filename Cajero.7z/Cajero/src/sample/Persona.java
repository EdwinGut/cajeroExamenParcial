package sample;

public class Persona {

    String nombre;
    String identificacion;

    public Persona(String nombre, String identificacion){

        this.nombre = nombre;
        this.identificacion = identificacion;
    }

}

