package sample;


import javafx.fxml.FXML;                       
import javafx.fxml.Initializable;              
import javafx.scene.control.Button;            
import javafx.scene.control.Label;             
import javafx.scene.control.TextField;         
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.input.MouseEvent;

import javax.swing.*;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    int saldo = 0;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    @FXML private TextField cajaDeTextoNombre;
    @FXML private TextField cajaDeTextoIdentificacion;
    @FXML private Label labelConfirmacionCuenta;
    @FXML private TextField cajaDeTextoDepositar;
    @FXML private TextField cajaDeTextoRetirar;
    @FXML private TextField cajaDeTextoTransferir;
    @FXML private Label labelConfirmacionDeposito;
    @FXML private Label labelConfirmacionRetiro;
    @FXML private Label labelConfirmacionTransferencia;
    @FXML private Label labelValorSaldo;


    public void botonCrearCuenta(ActionEvent event){

        Persona persona1 = new Persona(cajaDeTextoNombre.getText(), cajaDeTextoIdentificacion.getText());

        labelConfirmacionCuenta.setText("Cuenta creada" + " " + persona1.nombre + " " +persona1.identificacion);

        labelValorSaldo.setText(Integer.toString(saldo));
    }

    public void botonDepositar (ActionEvent event){

        int aux1 = Integer.parseInt(cajaDeTextoDepositar.getText());
        labelConfirmacionDeposito.setText("Deposito realizado");
        labelValorSaldo.setText(String.valueOf(saldo + aux1));

        saldo = saldo + aux1;

    }

    public void botonRetirar (ActionEvent event){

        if(saldo < Integer.parseInt(cajaDeTextoRetirar.getText())){
            labelConfirmacionRetiro.setText("No cuenta con saldo suficiente");
        }else{
            int aux1 = Integer.parseInt(cajaDeTextoRetirar.getText());
            labelConfirmacionRetiro.setText("Retiro realizado");
            labelValorSaldo.setText(String.valueOf(saldo - aux1));

            saldo = saldo - aux1;
        }

    }

    public void botonTransferir (ActionEvent event){

        if(saldo < Integer.parseInt(cajaDeTextoTransferir.getText())){
            labelConfirmacionRetiro.setText("No cuenta con saldo suficiente");
        }else{
            int aux1 = Integer.parseInt(cajaDeTextoTransferir.getText());
            labelConfirmacionTransferencia.setText("Transferencia realizada");
            labelValorSaldo.setText(String.valueOf(saldo + aux1));

            saldo = saldo - aux1;
        }
    }



}